The help files for this theme are in html format and can be found in the "docs" folder.

This will allow you to have the help files open in your browser whilst at the same time having your TXP admin open in another tab (window) and also your website open in yet another if you so wish.

You can then simply switch between tabs (windows) as necessary.

To open these help files simply go into the "docs" folder and click or double-click on the "index.html" file.