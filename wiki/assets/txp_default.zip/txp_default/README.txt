<!-- This file is optional document included by the template designer and not required for this template -->
<h1>TXP Default</h1>
<p>The purpose of this template is to provide an example template for Textpattern 4.3.0 that other designers can use to learn from. Please see the additional information area located below for template specific information.</p>
